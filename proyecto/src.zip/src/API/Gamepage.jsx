// Gamepage.jsx
import React, { useEffect, useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import axios from 'axios';
import NavBar from '../main/Navbar.jsx';
import 'bootstrap/dist/css/bootstrap.min.css';
import './Gamepage.css';
import GameLibrary from '../main/Biblioteca.jsx';
import { useCartState } from './CartContext'; // Import only useCartState
import CartDisplay from '../components/CartDisplay.js';

const API_url = 'https://api.rawg.io/api/games?key=a401ea2cd25341bba41b31571184b645';

function Gamepage() {
  const [juegos, setJuegos] = useState([]);
  const { addToCart } = useCartState(); // Use useCartState to get addToCart function
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    axios.get(API_url).then((response) => {
      console.log(response.data);
      setJuegos(response.data.results);
    });
  }, []);

  return (
    <div>
      <NavBar />
      <div className="container">
        <ul className="row list-unstyled">
          {juegos.map((juego) => (
            <li key={juego.id} className="col-md-3 mb-3">
              <div className="card h-100">
                <div>
                  <strong>Nombre:</strong> {juego.name}
                </div>
                {juego.background_image && (
                  <div>
                    <img src={juego.background_image} alt={juego.name} className="card-img-top img-fluid custom-img" />
                  </div>
                )}
                <div>
                  <strong >Valoración:</strong> <span>{juego.metacritic}%</span>
                </div>
                <div>
                  <strong>Lanzamiento:</strong> {new Date(juego.released).toLocaleDateString()}
                </div>
                <Link to="/carrito" onClick={() => addToCart(juego)}className="btn btn-primary">
                  Agregar al carrito
                </Link>
              </div>
            </li>
          ))}
        </ul>
      </div>
      {location.pathname === '/carrito' && <CartDisplay />}
    </div>
  );
}

export default Gamepage;
