

import React from 'react';
import { Link } from 'react-router-dom';
import { Navbar, Nav, NavDropdown } from 'react-bootstrap';
import '../components/Navbar.css';

function NavBar({ isAuthenticated }) {
  return (
    <Navbar bg="light" expand="lg">
      <Navbar.Brand as={Link} to="/">Vapor</Navbar.Brand>
      <Navbar.Toggle aria-controls="navbarNav" />
      <Navbar.Collapse id="navbarNav">
        <Nav className="mr-auto">
          <Nav.Link as={Link} to="/">Inicio</Nav.Link>
          <Nav.Link as={Link} to="/games">Catálogo de juegos</Nav.Link>
          <Nav.Link as={Link} to="/biblioteca">Biblioteca</Nav.Link>
          <Nav.Link as={Link} to="/perfil">Perfil</Nav.Link>
        </Nav>
        <Nav>
          {isAuthenticated ? (
            <NavDropdown title="Perfil" id="basic-nav-dropdown">
              <NavDropdown.Item as={Link} to="/perfil">Ver Perfil</NavDropdown.Item>
              <NavDropdown.Item as={Link} to="/cerrar-sesion">Cerrar Sesión</NavDropdown.Item>
            </NavDropdown>
          ) : (
            <NavDropdown title="Iniciar Sesión/Registrarse" id="basic-nav-dropdown">
              <NavDropdown.Item as={Link} to="/iniciarsesion">Iniciar Sesión</NavDropdown.Item>
              <NavDropdown.Item as={Link} to="/registrarse">Registrarse</NavDropdown.Item>
            </NavDropdown>
          )}
        </Nav>
      </Navbar.Collapse>
    </Navbar>
  );
}

export default NavBar;


