import '../App.css';
import Gamepage from "../API/Gamepage"
import Inicio from "./Inicio.jsx"
import { BrowserRouter, Routes, Route} from "react-router-dom";
import Profile from "./perfil.jsx"
import IniciarSesion from "./SignIn.jsx"
import Registrarse from "./SignUp.jsx"
import CartDisplay from '../components/CartDisplay.js';
import NavBar from './Navbar.jsx';
import ReactBootstrap, {Jumbotron, Button, Col, Grid, Panel, FormGroup} from 'react-bootstrap'
import GameLibrary from './Biblioteca.jsx';
import { CartStateProvider } from '../API/CartContext';

function App() {
  return (
    <BrowserRouter>
      <CartStateProvider>
        <Routes>
          <Route index element={<Inicio />} />
          <Route path="/games" element={<Gamepage />} />
          <Route path="/perfil" element={<Profile />} />
          <Route path="/biblioteca" element={<GameLibrary />} />
          <Route path="/Carrito" element={<CartDisplay />} />
          <Route path="/iniciarsesion" element={<IniciarSesion />} />
          <Route path="/registrarse" element={<Registrarse />} />
          <Route path="/perfil" element={<Profile />} />
        </Routes>
      </CartStateProvider>
    </BrowserRouter>
  );
}

export default App;

