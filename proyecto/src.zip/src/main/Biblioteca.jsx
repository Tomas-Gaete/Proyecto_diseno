import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';

import NavBar from './Navbar';
const GameLibrary = () => {
  const [libraryItems, setLibraryItems] = useState([]);

  const addToLibrary = (game) => {
    // Assuming 'game' is the game data
    const newLibraryItems = [...libraryItems, game];
    setLibraryItems(newLibraryItems);
  };

  return (
    <div>
        <NavBar/>
      <h2>Game Library</h2>
      <ul>
        {libraryItems.map((item, index) => (
          <li key={index}>{item.name /* Display relevant game information */}</li>
        ))}
      </ul>
      <Link to="/games" className="btn btn-primary">Explorar el catálogo</Link>
    </div>
  );
};

export default GameLibrary;
