import React from 'react';

const Library = () => {
 return (
    <div>
      <h1>Library</h1>
      <div className="center-text">
        <h2>No tienes juegos</h2>
      </div>
    </div>
 );
};

export default Library;